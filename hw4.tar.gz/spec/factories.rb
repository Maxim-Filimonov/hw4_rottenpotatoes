FactoryGirl.define do
  factory :movie do
    title 'Star wars'
    director 'George Lucas'
  end
end
